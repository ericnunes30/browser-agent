(function(){(function(){let n=null,b=null,a=null,r=null,c=null,o=null,E=0,k=0,p=!1,S=!1,s=null,x=null,I=!1,u=null,g=null,y=null,l=null;const N="#D97757",C="#FAF9F5",T="#141413",F="rgba(31, 30, 29, 0.30)";function M(t,i){const e=document.createElement("div");e.id="claude-phantom-cursor",e.setAttribute("aria-hidden","true"),e.style.cssText=`
      position: fixed;
      top: 0;
      left: 0;
      pointer-events: none;
      z-index: 2147483646;
      transform: translate3d(${t}px, ${i}px, 0);
      transition: transform 180ms cubic-bezier(0.2, 0, 0, 1), opacity 500ms ease;
      will-change: transform;
      opacity: 1;
    `;const m="M0 0 L0 18 L4.5 14 L7.5 21.5 L11 20 L8 13 L14 13 Z";function L(it,z,nt,ot=""){const H="http://www.w3.org/2000/svg",h=document.createElementNS(H,"svg");h.setAttribute("id",it),h.setAttribute("width","20"),h.setAttribute("height","26"),h.setAttribute("viewBox","0 0 20 26"),h.style.cssText=`position:absolute; top:0; left:0; overflow:visible; ${ot}`;const w=document.createElementNS(H,"path");w.setAttribute("d",m),w.setAttribute("stroke",z),w.setAttribute("stroke-width","3"),w.setAttribute("stroke-linejoin","round"),w.setAttribute("fill",z);const _=document.createElementNS(H,"path");return _.setAttribute("d",m),_.setAttribute("fill",nt),h.appendChild(w),h.appendChild(_),h}const f=L("claude-phantom-cursor-plain","white","#111",""),d=L("claude-phantom-cursor-styled",N,C,"filter: drop-shadow(0 0 4px rgba(217,119,87,0.9)) drop-shadow(0 0 10px rgba(217,119,87,0.45));");return e.appendChild(f),e.appendChild(d),document.body.appendChild(e),{container:e,styled:d}}function R(t,i){if(!p)return Promise.resolve();if(E=t,k=i,!n){const e=M(t,i);return n=e.container,b=e.styled,Promise.resolve()}return n.style.transform=`translate3d(${t}px, ${i}px, 0)`,n&&(n.style.opacity="1"),g&&clearTimeout(g),g=setTimeout(()=>{n&&p&&(n.style.opacity="0")},2e3),document.hidden?Promise.resolve():new Promise(e=>{let m=!1;const L=()=>{m||(m=!0,n==null||n.removeEventListener("transitionend",L),e())};n==null||n.addEventListener("transitionend",L,{once:!0}),setTimeout(L,220)})}function B(){n!=null&&n.parentNode&&n.parentNode.removeChild(n),n=null,b=null,g&&(clearTimeout(g),g=null)}function U(t,i){const e=document.createElement("div");e.id="claude-click-ripple",e.style.cssText=`
      position: fixed;
      left: ${t-12}px;
      top: ${i-12}px;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: rgba(217, 119, 87, 0.4);
      box-shadow: 0 0 10px 2px rgba(217, 119, 87, 0.3);
      pointer-events: none;
      z-index: 2147483647;
      animation: claude-ripple 400ms ease-out forwards;
    `,document.body.appendChild(e),e.addEventListener("animationend",()=>{e.remove()},{once:!0})}function P(){if(!document.getElementById("claude-agent-animation-styles")){const t=document.createElement("style");t.id="claude-agent-animation-styles",t.textContent=`
        @keyframes claude-pulse {
          0% {
            box-shadow:
              inset 0 0 10px rgba(217, 119, 87, 0.5),
              inset 0 0 20px rgba(217, 119, 87, 0.3),
              inset 0 0 30px rgba(217, 119, 87, 0.1);
          }
          50% {
            box-shadow:
              inset 0 0 15px rgba(217, 119, 87, 0.7),
              inset 0 0 25px rgba(217, 119, 87, 0.5),
              inset 0 0 35px rgba(217, 119, 87, 0.2);
          }
          100% {
            box-shadow:
              inset 0 0 10px rgba(217, 119, 87, 0.5),
              inset 0 0 20px rgba(217, 119, 87, 0.3),
              inset 0 0 30px rgba(217, 119, 87, 0.1);
          }
        }
        @keyframes claude-ripple {
          0% { transform: scale(0); opacity: 1; }
          50% { transform: scale(1); opacity: 0.7; }
          100% { transform: scale(1.5); opacity: 0; }
        }
        @keyframes claude-fade-in {
          0% { opacity: 0; transform: translateX(-50%) translateY(-4px); }
          100% { opacity: 1; transform: translateX(-50%) translateY(0); }
        }
      `,document.head.appendChild(t)}a?a.style.display="":(a=document.createElement("div"),a.id="claude-agent-glow-border",a.style.cssText=`
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        pointer-events: none;
        z-index: 2147483646;
        opacity: 0;
        transition: opacity 0.3s ease-in-out;
        animation: claude-pulse 2s ease-in-out infinite;
        box-shadow:
          inset 0 0 10px rgba(217, 119, 87, 0.5),
          inset 0 0 20px rgba(217, 119, 87, 0.3),
          inset 0 0 30px rgba(217, 119, 87, 0.1);
      `,document.body.appendChild(a))}function V(){if(r)r.style.display="";else{r=document.createElement("div"),r.id="claude-agent-stop-container",r.style.cssText=`
        position: fixed;
        bottom: 16px;
        left: 16px;
        display: flex;
        justify-content: center;
        align-items: center;
        pointer-events: none;
        z-index: 2147483647;
      `,c=document.createElement("button"),c.id="claude-agent-stop-button",c.textContent="Stop",c.style.cssText=`
        position: relative;
        transform: translateY(100px);
        padding: 10px 20px;
        background: #D97757;
        color: #fff;
        border: none;
        border-radius: 8px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 2px 8px rgba(217, 119, 87, 0.4);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        opacity: 0;
        user-select: none;
        pointer-events: auto;
        white-space: nowrap;
      `;const t=c;t.addEventListener("mouseenter",()=>{p&&(t.style.background="#C05E3A")}),t.addEventListener("mouseleave",()=>{p&&(t.style.background="#D97757")}),c.addEventListener("click",async()=>{try{await chrome.runtime.sendMessage({type:"indicator:stop"})}catch{}}),r.appendChild(c),document.body.appendChild(r)}}function G(t){v(),y=document.createElement("div"),y.id="claude-action-label",y.textContent=t,y.style.cssText=`
      position: fixed;
      top: 16px;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(0, 0, 0, 0.75);
      color: #fff;
      font-size: 12px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      padding: 6px 14px;
      border-radius: 8px;
      backdrop-filter: blur(4px);
      pointer-events: none;
      z-index: 2147483647;
      white-space: nowrap;
      animation: claude-fade-in 150ms ease-out forwards;
    `,document.body.appendChild(y)}function v(){y&&(y.remove(),y=null)}function D(){if(document.getElementById("ba-static-dot"))return;const t=document.createElement("div");t.id="ba-static-dot",t.title="BrowserAgent is active",t.style.cssText=`
      position: fixed;
      top: 8px;
      right: 8px;
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background: #D97757;
      box-shadow: 0 0 4px rgba(217, 119, 87, 0.5);
      z-index: 2147483647;
      pointer-events: none;
      animation: ba-pulse 2s ease-in-out infinite;
    `,document.body.appendChild(t)}function X(){const t=document.getElementById("ba-static-dot");t&&t.remove()}function O(){if(document.getElementById("ba-animations"))return;const t=document.createElement("style");t.id="ba-animations",t.textContent=`
      @keyframes ba-pulse {
        0%, 100% { opacity: 0.6; }
        50% { opacity: 1; }
      }
    `,document.head.appendChild(t)}function Z(t,i,e,m){l&&(l.remove(),l=null);const L="http://www.w3.org/2000/svg",f=document.createElementNS(L,"svg");f.setAttribute("id","claude-drag-path"),f.setAttribute("width","100%"),f.setAttribute("height","100%"),f.style.cssText=`
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 2147483647;
    `;const d=document.createElementNS(L,"line");d.setAttribute("x1",String(t)),d.setAttribute("y1",String(i)),d.setAttribute("x2",String(e)),d.setAttribute("y2",String(m)),d.setAttribute("stroke","#E74C3C"),d.setAttribute("stroke-width","2"),d.setAttribute("stroke-dasharray","6,4"),d.setAttribute("stroke-linecap","round"),f.appendChild(d),document.body.appendChild(f),l=f,setTimeout(()=>{l&&(l.remove(),l=null)},1e3)}function j(){if(!s)try{s=new AudioContext;const t=s.createGain();t.value=0,t.connect(s.destination);const i=s.createConstantSource();i.connect(t),i.start(),document.addEventListener("pointerdown",()=>{p&&(s==null||s.resume().catch(()=>{}))},{capture:!0})}catch{}}function W(){try{s==null||s.resume().catch(()=>{})}catch{}}function Y(){p=!0,P(),V(),a&&(a.style.opacity="1"),c&&(c.style.transform="translateY(0)",c.style.opacity="1");const t=E||Math.round(window.innerWidth/2),i=k||Math.round(window.innerHeight/2);if(!n){const e=M(t,i);n=e.container,b=e.styled,E=t,k=i}j(),W()}function $(){p&&(p=!1,a&&(a.style.opacity="0"),c&&(c.style.transform="translateY(100px)",c.style.opacity="0"),v(),l&&(l.remove(),l=null),setTimeout(()=>{p||(a!=null&&a.parentNode&&a.parentNode.removeChild(a),a=null,r!=null&&r.parentNode&&r.parentNode.removeChild(r),r=null,c=null,B())},300),s==null||s.suspend().catch(()=>{}))}function q(){if(S=!0,o)o.style.display="";else{o=document.createElement("div"),o.id="claude-static-indicator-container",o.innerHTML=`
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 16px; height: 16px; display: inline-block; vertical-align: middle; flex-shrink: 0; margin-right: 8px;">
          <path d="M3.13946 10.6399L6.28757 8.87462L6.37405 8.73821L6.28757 8.6339H6.13189L5.60432 8.6018L3.80541 8.55366L2.24865 8.48947L0.735135 8.40923H0.492973L0.354595 8.32899L0.181622 8.1685L0.0345946 8.01605L0 7.85557L0.0345946 7.62287L0.138378 7.44634L0.224865 7.40622H0.354595L0.812973 7.44634L1.82486 7.51856L3.34703 7.62287L4.44541 7.68706L6.08 7.85557H6.33946L6.37405 7.75125L6.28757 7.68706L6.21838 7.62287L4.64432 6.55567L2.94054 5.4323L2.04973 4.78235L1.57405 4.45336L1.33189 4.14845L1.22811 3.92377L1.17622 3.69107L1.22811 3.47442L1.33189 3.28185L1.46162 3.13741L1.66054 2.99298H1.87676L2.24865 3.0331L2.39568 3.07322L2.99243 3.53059L4.26378 4.51755L5.92432 5.73721L6.16649 5.93781H6.27892V5.82548L6.16649 5.64092L5.26703 4.01204L4.30703 2.35105L3.87459 1.66098L3.76216 1.25176C3.7391 1.16082 3.69297 0.977332 3.69297 0.970913V0.762287L3.77946 0.505517L3.93513 0.240722L4.18595 0.0882648L4.4627 0H4.67892L4.83459 0.0240722L5.12865 0.0882648L5.4054 0.328987L5.82054 1.27583L6.48649 2.76028L7.52432 4.78235L7.82703 5.38415L7.99135 5.93781L8.05189 6.10632H8.15567V6.01003L8.24216 4.87061L8.39784 3.47442L8.55351 1.67703L8.6054 1.17151L8.85622 0.561685L8.9773 0.417252L9.21946 0.232698H9.35784L9.74703 0.417252L9.97189 0.665998L10.067 0.874624L10.0238 1.17151L9.83351 2.40722L9.46162 4.34102L9.21946 5.64092H9.35784L9.52216 5.47242L10.1795 4.60582L11.2778 3.22568L11.7622 2.68004L12.333 2.07823L12.6962 1.78937L13.0162 1.67703L13.3881 1.78937L13.7168 2.06219L13.8897 2.54363V2.76028L13.6649 3.32197L12.9557 4.22066L12.3676 4.98295L12.0043 5.56871L11.0011 7.02106V7.08526H11.1741L13.0768 6.67603L14.1059 6.49147L15.3341 6.28285L15.5762 6.34704L15.8876 6.53962L15.9481 6.80441L15.8876 7.12538L15.7319 7.34203L14.4173 7.66299L12.8778 7.97593L10.5854 8.51559C10.5705 8.51909 10.56 8.53236 10.56 8.54764C10.56 8.56468 10.573 8.57891 10.59 8.58044L11.6238 8.67402L12.0649 8.69809H13.1459L15.1611 8.85055L15.6886 9.19559L15.9481 9.39619L16 9.62086L15.9481 9.94985L15.8443 10.1023L15.4119 10.3029L15.1351 10.3591L14.0454 10.1023L11.4941 9.49248L10.6205 9.27583H10.4995V9.34804L11.2259 10.0622L12.5665 11.2658L14.2357 12.8225L14.3222 13.0953V13.2076L14.1059 13.5125L13.9243 13.5206L13.8811 13.4804L12.4108 12.3731L12.2984 12.325L11.84 11.8756L10.56 10.7924H10.4735V10.9047L10.7676 11.338L12.333 13.6891L12.4108 14.4112L12.2984 14.6439L11.8919 14.7884L11.667 14.7563L11.4508 14.7081L11.2605 14.5396L10.5254 13.4162L9.5827 11.9719L8.82162 10.672H8.79342C8.76039 10.672 8.73278 10.6972 8.7297 10.73L8.27676 15.5667L8.06919 15.8154L7.6454 16H7.58486L7.17838 15.6951L6.96216 15.1976L7.17838 14.2106L7.43784 12.9268L7.6454 11.9077L7.83567 10.6399L7.95187 10.2164C7.9548 10.2057 7.95069 10.1944 7.94161 10.1881C7.91157 10.1672 7.87034 10.1741 7.84878 10.2037L6.89297 11.5145L5.44 13.4804L4.28973 14.7081L4.01297 14.8205H3.80541L3.5373 14.5717V14.4514L3.58054 14.1304L3.84865 13.7372L5.44 11.7151L6.4 10.4554L7.01872 9.73222C7.04511 9.70139 7.04245 9.65523 7.0127 9.62763C7.00333 9.61894 6.98925 9.61773 6.97854 9.62471L2.75027 12.3811L1.99784 12.4774L1.66919 12.1725L1.71243 11.675L1.86811 11.5145L3.13946 10.6399Z" fill="${N}"/>
        </svg>
        <span style="vertical-align: middle; color: ${T}; font-size: 14px; display: inline-block;">Claude is active in this tab group</span>
        <div style="display: inline-block; width: 0.5px; height: 32px; background: rgba(31, 30, 29, 0.15); margin: 0 8px; vertical-align: middle;"></div>
        <button id="claude-static-chat-button" style="position: relative; display: inline-flex; align-items: center; justify-content: center; padding: 6px; background: transparent; border: none; cursor: pointer; pointer-events: auto; vertical-align: middle; width: 32px; height: 32px; border-radius: 8px; transition: background 0.2s;">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="${T}" xmlns="http://www.w3.org/2000/svg" style="width: 20px; height: 20px; display: block;">
            <path d="M10 2.5C14.1421 2.5 17.5 5.85786 17.5 10C17.5 14.1421 14.1421 17.5 10 17.5H3C2.79779 17.5 2.61549 17.3782 2.53809 17.1914C2.4607 17.0046 2.50349 16.7895 2.64648 16.6465L4.35547 14.9365C3.20124 13.6175 2.5 11.8906 2.5 10C2.5 5.85786 5.85786 2.5 10 2.5ZM10 3.5C6.41015 3.5 3.5 6.41015 3.5 10C3.5 11.7952 4.22659 13.4199 5.40332 14.5967L5.46582 14.6729C5.52017 14.7544 5.5498 14.8508 5.5498 14.9502C5.5498 15.0828 5.49709 15.2099 5.40332 15.3037L4.20703 16.5H10C13.5899 16.5 16.5 13.5899 16.5 10C16.5 6.41015 13.5899 3.5 10 3.5ZM13.29 9.30371C13.3986 9.05001 13.6925 8.93174 13.9463 9.04004C14.2 9.14863 14.3183 9.44253 14.21 9.69629C13.8506 10.536 13.1645 11.25 12.25 11.25C11.6372 11.25 11.128 10.9289 10.75 10.4648C10.372 10.9289 9.86276 11.25 9.25 11.25C8.63724 11.25 8.12801 10.9289 7.75 10.4648C7.37198 10.9289 6.86276 11.25 6.25 11.25C5.97386 11.25 5.75 11.0261 5.75 10.75C5.75 10.4739 5.97386 10.25 6.25 10.25C6.58764 10.25 7.00448 9.97056 7.29004 9.30371L7.32422 9.2373C7.41431 9.09121 7.5749 9 7.75 9C7.9501 9 8.13123 9.11975 8.20996 9.30371L8.32227 9.53516C8.59804 10.0359 8.95442 10.25 9.25 10.25C9.58764 10.25 10.0045 9.97056 10.29 9.30371L10.3242 9.2373C10.4143 9.09121 10.5749 9 10.75 9C10.9501 9 11.1312 9.11975 11.21 9.30371L11.3223 9.53516C11.598 10.0359 11.9544 10.25 12.25 10.25C12.5876 10.25 13.0045 9.97056 13.29 9.30371Z" />
          </svg>
          <span id="claude-static-chat-tooltip" style="position: absolute; bottom: calc(100% + 12px); left: 50%; transform: translateX(-50%); padding: 6px 12px; background: #30302E; color: ${C}; border-radius: 6px; font-size: 12px; white-space: nowrap; opacity: 0; pointer-events: none; transition: opacity 0.2s; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">Open chat</span>
        </button>
        <button id="claude-static-close-button" style="position: relative; display: inline-flex; align-items: center; justify-content: center; padding: 6px; background: transparent; border: none; cursor: pointer; pointer-events: auto; vertical-align: middle; width: 32px; height: 32px; margin-left: 4px; border-radius: 8px; transition: background 0.2s;">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 20px; height: 20px; display: block;">
            <path d="M15.1464 4.14642C15.3417 3.95121 15.6582 3.95118 15.8534 4.14642C16.0486 4.34168 16.0486 4.65822 15.8534 4.85346L10.7069 9.99997L15.8534 15.1465C16.0486 15.3417 16.0486 15.6583 15.8534 15.8535C15.6826 16.0244 15.4186 16.0461 15.2245 15.918L15.1464 15.8535L9.99989 10.707L4.85338 15.8535C4.65813 16.0486 4.34155 16.0486 4.14634 15.8535C3.95115 15.6583 3.95129 15.3418 4.14634 15.1465L9.29286 9.99997L4.14634 4.85346C3.95129 4.65818 3.95115 4.34162 4.14634 4.14642C4.34154 3.95128 4.65812 3.95138 4.85338 4.14642L9.99989 9.29294L15.1464 4.14642Z" fill="${T}"/>
          </svg>
          <span id="claude-static-close-tooltip" style="position: absolute; bottom: calc(100% + 12px); left: 50%; transform: translateX(-50%); padding: 6px 12px; background: #30302E; color: ${C}; border-radius: 6px; font-size: 12px; white-space: nowrap; opacity: 0; pointer-events: none; transition: opacity 0.2s; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">Dismiss</span>
        </button>
      `,o.style.cssText=`
        position: fixed;
        bottom: 16px;
        left: 50%;
        transform: translateX(-50%);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 6px 6px 6px 16px;
        background: ${C};
        border: 0.5px solid ${F};
        border-radius: 14px;
        box-shadow: 0 40px 80px 0 rgba(0, 0, 0, 0.15);
        z-index: 2147483647;
        pointer-events: none;
        white-space: nowrap;
        user-select: none;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      `;const t=o.querySelector("#claude-static-chat-button");if(t){const e=o.querySelector("#claude-static-chat-tooltip");t.addEventListener("mouseenter",()=>{t.style.background="#F0EEE6",e&&(e.style.opacity="1")}),t.addEventListener("mouseleave",()=>{t.style.background="transparent",e&&(e.style.opacity="0")}),t.addEventListener("click",async()=>{try{await chrome.runtime.sendMessage({type:"SWITCH_TO_MAIN_TAB"})}catch{}})}const i=o.querySelector("#claude-static-close-button");if(i){const e=o.querySelector("#claude-static-close-tooltip");i.addEventListener("mouseenter",()=>{i.style.background="#F0EEE6",e&&(e.style.opacity="1")}),i.addEventListener("mouseleave",()=>{i.style.background="transparent",e&&(e.style.opacity="0")}),i.addEventListener("click",async()=>{try{await chrome.runtime.sendMessage({type:"DISMISS_STATIC_INDICATOR_FOR_GROUP"})}catch{}})}document.body.appendChild(o)}x&&clearInterval(x),x=setInterval(async()=>{try{const t=await chrome.runtime.sendMessage({type:"STATIC_INDICATOR_HEARTBEAT"});t!=null&&t.success||A()}catch{A()}},5e3)}function A(){S=!1,x&&(clearInterval(x),x=null),o!=null&&o.parentNode&&(o.parentNode.removeChild(o),o=null)}function K(){I=p,a&&(a.style.display="none"),r&&(r.style.display="none"),b&&(b.style.display="none"),o&&(o.style.display="none"),v(),l&&(l.style.display="none")}function J(){I&&(a&&(a.style.display=""),r&&(r.style.display=""),b&&(b.style.display="")),S&&o&&(o.style.display=""),l&&(l.style.display="")}function Q(t){return`<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 256 256">
    <path fill="${t?"#D97757":"#BF5A3A"}" d="M208 40H48a8 8 0 0 0-8 8v58.77c0 88.62 49.33 109.58 73.68 118.44a52.67 52.67 0 0 0 12.32 2.79h.13a51.15 51.15 0 0 0 12.86-2.79C166.67 216.35 216 195.39 216 106.77V48a8 8 0 0 0-8-8Zm-64 152h-32v-56h32Z"/>
  </svg>`}function tt(t){var e;u||(u=document.createElement("div"),u.id="ba-shield-indicator",document.body.appendChild(u));const i=!document.body.classList.contains("light")&&((e=getComputedStyle(document.body).backgroundColor)==null?void 0:e.startsWith("rgb(255"))===!1;u.innerHTML=Q(i),u.style.cssText=`
      position: fixed;
      top: 8px;
      right: 8px;
      z-index: 2147483646;
      cursor: default;
      pointer-events: none;
      opacity: ${t?1:.5};
      transition: opacity 0.2s;
      ${t?"filter: drop-shadow(0 0 4px rgba(217, 119, 87, 0.5));":""}
    `}function et(){u&&(u.remove(),u=null)}chrome.runtime.onMessage.addListener((t,i,e)=>{switch(t.type){case"SHOW_AGENT_INDICATORS":t.isMcp,Y(),e({success:!0});break;case"HIDE_AGENT_INDICATORS":$(),X(),e({success:!0});break;case"UPDATE_PHANTOM_CURSOR":return R(t.x,t.y).then(()=>e({success:!0})),!0;case"HIDE_FOR_TOOL_USE":K(),e({success:!0});break;case"SHOW_AFTER_TOOL_USE":J(),e({success:!0});break;case"SHOW_STATIC_INDICATOR":O(),D(),q(),e({success:!0});break;case"HIDE_STATIC_INDICATOR":A(),e({success:!0});break;case"indicator:action":t.text?G(t.text):v(),e({success:!0});break;case"indicator:show":D(),O(),e({success:!0});break;case"indicator:hide_action":v(),e({success:!0});break;case"indicator:click_ripple":t.coordinate&&Array.isArray(t.coordinate)&&t.coordinate.length>=2&&U(t.coordinate[0],t.coordinate[1]),e({success:!0});break;case"indicator:drag_path":t.start_coordinate&&t.coordinate&&Array.isArray(t.start_coordinate)&&Array.isArray(t.coordinate)&&t.start_coordinate.length>=2&&t.coordinate.length>=2&&Z(t.start_coordinate[0],t.start_coordinate[1],t.coordinate[0],t.coordinate[1]),e({success:!0});break;case"indicator:shield":t.show?tt(t.restricted??!0):et(),e({success:!0});break}}),window.addEventListener("beforeunload",()=>{$(),A(),B(),v(),l&&(l.remove(),l=null),s==null||s.close().catch(()=>{}),s=null})})();
})()
