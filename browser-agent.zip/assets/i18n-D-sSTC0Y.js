import{r as e,g as s}from"./client-B_0kvymi.js";var a=e();const g=s(a);function m(r,...t){return chrome.i18n.getMessage(r,t)||r}export{g as R,a as r,m as t};
